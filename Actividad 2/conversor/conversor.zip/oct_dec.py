def oct_dec(octal):
	octal = int(octal)
	decimal = 0
	base = 1
	while not octal<8:
		digito = octal%10
		octal -= digito
		decimal = decimal + digito*base
		octal = octal//10
		base = base*8
	decimal = decimal + octal*base
	return decimal
if __name__ == "__main__":
	while True:
		a = int(input("Octal: "))
		print("decimal: " + oct_to_dec(a))
def dec_bin2(_numero):
	_binario = []
	while not _numero==1:
		if (_numero%2) == 1:
			_numero -=1
			_binario.append("1")
		else:
			_binario.append("0")
		_numero = _numero/2
	_binario.append("1")
	_binario = _binario[::-1]
	_binario = "".join(_binario)
	return _binario
def dec_bin(_dec):
	_binario = 0
	_vueltas = 0
	_digito = 0
	#print("Iniciacion, bin",_binario,"vueltas",_vueltas,"digito",_digito,"decimal",_dec)
	while not _dec <=1:
		_digito = _dec%2
		#print("digito",_digito)
		if _digito == 1:
			_dec-=1
		#print("decimal despues condicional",_dec)
		_binario += _digito*10**_vueltas
		#print("bin", _binario)
		_dec = _dec//2
		#print("dec",_dec)
		_vueltas += 1
		#print("vueltas",_vueltas)
		#print("-----")
	_binario += _dec*10**_vueltas
	#print("binario final",_binario)
	return str(_binario)

def main():
	while True:
		numero = input("Ingrese numero: ").replace(" ", "")
		if numero.isnumeric():
			numero = int(numero)
			break
		else:
			print("Numero Invalido. Por favor no ingresar letras en el numero")
	binario = dec_bin(numero)
	print(f"Numero Decimal: {numero}\nNumero Binario: {''.join(binario)}\nCantidad de Bits: {len(binario)}") 

if __name__ == "__main__":
	print("Conversor de numero decimal a binario")
	while True:
		main()
		print("\n")
def hex_dec(hexadecimal):
	hexadecimal = hexadecimal.replace(" ","")
	hex_chars = "0123456789ABCDEF"
	decimal = 0
	base = 1
	for aux in hexadecimal[::-1]:
		aux1 = hex_chars.index(str(aux.upper()))
		decimal += aux1*base
		base*=16
	return decimal
if __name__ == "__main__":
	while True:
		a = str(input("hexadecimal: "))
		print("decimal: " + str(hex_dec(a)))
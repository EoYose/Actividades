def dec_hex(decimal):
	hexadecimal = ""
	hex_list = "0123456789ABCDEF"
	while not decimal < 16:
		digito = decimal%16
		decimal -=digito
		hexadecimal = hexadecimal + hex_list[digito]
		decimal = decimal//16
	hexadecimal = hex_list[decimal] + hexadecimal
	return hexadecimal
if __name__ == "__main__":
	while True:
		print("Hexadecimal " + str(dec_to_hex(int(input("Decimal: ")))))